function [z] = vector_nature(A);
[m,n]=size(A); 
idx=1;
j=1;
while j <= n %if matrix formed by culumn vector is not square
    if A(idx:m,j)==0 %iterate to find that whole column equal to zero 
      j=j+1;
    else
         for i=idx+1:m   %swapping of row 
                 if abs(A(i,j))>abs(A(idx,j))
                     temp1=A(i,:);
                     A(i,:)=A(idx,:);
                     A(idx,:)=temp1;             
                 end
         end
            %making of all entry below the pivoting equal to zero  
         for k=idx+1:m
              a=A(k,j)/A(idx,j);
              A(k,:)=A(k,:)-a*A(idx,:);
         end
        j=j+1;
        idx=idx+1;
    end
        z=A;
end
%checking of types of column vectors

dim=0;
for i=1:m
    count=0;
    for j=1:n
          if abs(z(i,j))<0.000001
              count=count+1 ;            
          end
    end
    if count==n
        dim=dim+1;
    end    
          
end
rank=min(m,n)-dim;
if rank==min(m,n)    
       disp("The given set of input vectors are linear independent")
else
      disp("The given set of input vectors are linear dependent")
end
end