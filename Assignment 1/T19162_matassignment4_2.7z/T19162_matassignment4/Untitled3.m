clc
prompt='Number of column vector to be entered : ';
value=input(prompt);
length=input('length of each column vector:  ');
A=[];
for i=1:value
  x=input('Input the column vector: ');  
  A=horzcat(A,x'); 
end  
disp("The matrix of column vector")
disp(A)
%calling of function to check that they are linear dependent or independent
vector_nature(A);
largest_lidset(A);
largest_lid3set(A);
basis_matrix(A);
