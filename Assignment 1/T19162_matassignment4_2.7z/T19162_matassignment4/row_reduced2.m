function [z,Y] = row_reduced2(A);
[m,n]=size(A); 
idx=1;
j=1;
X=[1:m];
while j <= n %if matrix formed by culumn vector is not square
    if A(idx:m,j)==0 %iterate to find that whole column equal to zero 
      j=j+1;
    else
         for i=idx+1:m   %swapping of row 
                 if abs(A(i,j))>abs(A(idx,j))
                     temp1=A(i,:);
                     A(i,:)=A(idx,:);
                     A(idx,:)=temp1;
                     temp2=X(:,i);
                     X(:,i)=X(:,idx); %swapping of indexing corresponding to row
                     X(:,idx)=temp2;                    
                 end
         end
            %making of all entry below the pivoting equal to zero  
         for k=idx+1:m
              a=A(k,j)/A(idx,j);
              A(k,:)=A(k,:)-a*A(idx,:);
         end
        j=j+1;
        idx=idx+1;
    end
        z=A;
        Y=X;
end

end