%finding of row reduced using row reduced transformation
function[z]=largest_lid3set(A);
temp=A';
[B R]=row_reduced2(temp);
temp1=B;
temp2=[];
%m=size(temp1,2);
for i=1:size(temp1,1)
    count=0;
    for j=1:size(temp1,2)
        if  abs(temp1(i,j)) <0.00001
            count=count+1;
        end
    end
    %collection of linearly independent vectors 
    if count~=size(temp1,2)
         temp2=horzcat(temp2,A(:,(R(:,i))));
    end     
end
z=temp2;
disp("largest independent subset of vectors")
disp(num2str(z))
end