function[z]=basis_matrix(A);
temp=A';
%calling of function to reduce to ecleon form
[B R]=row_reduced2(temp);
temp1=B;
temp2=[];
%m=size(temp1,2);
for i=1:size(temp1,1)
    count=0;
    for j=1:size(temp1,2)
        if  abs(temp1(i,j)) <0.00001
            count=count+1;
        end
    end
    if count~=size(temp1,2)
         temp2=horzcat(temp2,A(:,(R(:,i))));
    end     
end
z=temp2;
dimension=size(temp2,2);
disp("The basis of vector space")
disp(num2str(z))
disp("The dimension of vector space")
disp(num2str(dimension))

end

    
    
    
    
