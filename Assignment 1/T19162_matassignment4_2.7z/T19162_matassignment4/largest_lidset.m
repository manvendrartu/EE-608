%To find out largest linearly independent set of vectors by rank method
function[z]=largest_lidset(A);
[m,n]=size(A);
temp=A(:,1); %intialising of temp matrix 
for i=2:n
    temp1=temp;
    temp2=horzcat(temp1,A(:,i));
    if rank(temp2) >rank(temp1)
        temp=temp2;    %if independent
    else
        temp=temp1;  %if dependent
    end
end
z=temp;
disp("largest independent subset of vectors")
disp(num2str(z))
end
